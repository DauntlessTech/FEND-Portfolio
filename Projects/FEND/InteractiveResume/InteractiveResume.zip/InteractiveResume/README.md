## INTERACTIVE RESUME | 5-2-16

This project was made for the Udacity Front End Developer Nanodegree.

It utilizes JSON objects and dynamic HTML loading to build an online portfolio.

### Recently added Features
 - JQuery animations for opening and closing sections
 - Buttons to open and close sections now toggle between - and +
